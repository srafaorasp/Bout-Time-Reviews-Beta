// Developer mode is turned ON.
// To enable, rename this file to "dev.js" and overwrite the existing one.

import { state } from './state.js';
import { showToast, updateScoresAndDisplay } from './ui.js';

/**
 * Flag indicating if developer mode is active. This file sets it to true.
 * @type {boolean}
 */
export const isDevMode = true;

/**
 * Initializes the developer tools by creating and adding the UI to the page.
 */
export function initializeDevTools() {
    // Log a message to the console to confirm that dev mode is active.
    console.log('%cDEV MODE ACTIVATED', 'color: #FBBF24; font-size: 20px; font-weight: bold; text-shadow: 1px 1px 0 #000;');
    addDevPanel();
}

/**
 * Creates the developer panel HTML and attaches event listeners for the buttons.
 */
function addDevPanel() {
    const container = document.createElement('div');
    container.className = 'fixed bottom-4 left-4 bg-gray-900 bg-opacity-80 p-2 rounded-lg shadow-lg z-[100] space-y-2 border border-amber-400';
    container.innerHTML = `
        <h3 class="text-amber-400 font-bold text-center text-sm">Dev Tools</h3>
        <button id="dev-win-f1" class="w-full bg-blue-600 hover:bg-blue-700 text-white text-xs py-1 px-2 rounded">Force P1 Win</button>
        <button id="dev-win-f2" class="w-full bg-purple-600 hover:bg-purple-700 text-white text-xs py-1 px-2 rounded">Force P2 Win</button>
        <button id="dev-log-state" class="w-full bg-green-600 hover:bg-green-700 text-white text-xs py-1 px-2 rounded">Log State to Console</button>
    `;
    document.body.appendChild(container);

    // Event listener to force a win for Fighter 1 by manipulating scores
    document.getElementById('dev-win-f1').addEventListener('click', () => {
        if (!state.fighter1 || !state.fighter2) {
            showToast('Load both fighters first!');
            return;
        }
        state.fighter1.scores.metacritic = "100";
        state.fighter2.scores.metacritic = "1";
        updateScoresAndDisplay();
        showToast('Fighter 1 win condition forced!');
    });

    // Event listener to force a win for Fighter 2
    document.getElementById('dev-win-f2').addEventListener('click', () => {
        if (!state.fighter1 || !state.fighter2) {
            showToast('Load both fighters first!');
            return;
        }
        state.fighter1.scores.metacritic = "1";
        state.fighter2.scores.metacritic = "100";
        updateScoresAndDisplay();
        showToast('Fighter 2 win condition forced!');
    });

    // Event listener to log the entire current state object to the developer console
    document.getElementById('dev-log-state').addEventListener('click', () => {
        console.log('--- CURRENT GAME STATE ---', state);
        showToast('Current state logged to console.');
    });
}